package com.amir.jalalitoday

import java.time.LocalDate

data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    fun formatted(): String = "%04d/%02d/%02d".format(year, month, day)
}

/** Gregorian to Jalali conversion using the established break-year algorithm. */
object JalaliDateConverter {
    private val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)

    fun fromGregorian(date: LocalDate): JalaliDate {
        val gy = date.year
        val gm = date.monthValue
        val gd = date.dayOfMonth
        val gdm = intArrayOf(0, 31, if (isLeapGregorian(gy)) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gy2 = gy + 1
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd
        for (i in 0 until gm) days += gdm[i]
        var jy = -1595 + 33 * (days / 12053).toInt()
        days %= 12053
        jy += 4 * (days / 1461).toInt()
        days %= 1461
        if (days > 365) {
            jy += ((days - 1) / 365).toInt()
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31).toInt()
            jd = 1 + (days % 31).toInt()
        } else {
            jm = 7 + ((days - 186) / 30).toInt()
            jd = 1 + ((days - 186) % 30).toInt()
        }
        return JalaliDate(jy, jm, jd)
    }

    private fun isLeapGregorian(y: Int) = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)
}
