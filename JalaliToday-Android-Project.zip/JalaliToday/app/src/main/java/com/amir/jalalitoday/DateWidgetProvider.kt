package com.amir.jalalitoday

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

class DateWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == Intent.ACTION_DATE_CHANGED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, DateWidgetProvider::class.java))
            onUpdate(context, manager, ids)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val date = LocalDate.now()
        val jalali = JalaliDateConverter.fromGregorian(date)
        val day = date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("fa", "IR"))
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.date_widget)
            views.setTextViewText(R.id.widgetDate, jalali.formatted().toPersianDigits())
            views.setTextViewText(R.id.widgetDay, day)
            manager.updateAppWidget(id, views)
        }
    }
}
