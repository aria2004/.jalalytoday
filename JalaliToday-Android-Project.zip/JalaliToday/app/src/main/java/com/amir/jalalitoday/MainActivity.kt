package com.amir.jalalitoday

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val today = LocalDate.now()
        val jalali = JalaliDateConverter.fromGregorian(today)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF101B2D.toInt())
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false, margin: Int = 0) {
            val view = TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                if (margin > 0) setPadding(0, margin, 0, 0)
            }
            root.addView(view, LinearLayout.LayoutParams(-1, -2))
        }
        label("امروز", 18f, 0xFF9DB7DD.toInt(), true, 8)
        label(jalali.formatted().toPersianDigits(), 38f, 0xFFFFFFFF.toInt(), true, 22)
        val dayName = today.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("fa", "IR"))
        label(dayName, 22f, 0xFFE3ECFA.toInt(), true, 12)
        label("میلادی: ${today.year}/${today.monthValue.toString().padStart(2, '0')}/${today.dayOfMonth.toString().padStart(2, '0')}".toPersianDigits(), 15f, 0xFF9DB7DD.toInt(), false, 24)
        label("برای افزودن ویجت، روی صفحه اصلی نگه دار و بخش ابزارک‌ها را باز کن.", 13f, 0xFFB8C6DA.toInt(), false, 48)
        setContentView(root)
    }
}

fun String.toPersianDigits(): String = map { if (it in '0'..'9') ('۰'.code + (it.code - '0'.code)).toChar() else it }.joinToString("")
